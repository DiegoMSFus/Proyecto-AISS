package aiss.github.service;

import aiss.github.etl.Transformer;
import aiss.github.model.Issue;
import aiss.github.model.issuedata.IssueData;
import aiss.github.model.Comment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class IssueService {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private Transformer transformer;

    @Autowired
    private CommentService commentService;

    @Value("${github.token}")
    private String token;

    @Value("${github.baseuri}")
    private String baseUri;

    public List<Issue> getIssues(String owner, String repo, Integer pages) {
        String uri = baseUri + owner + "/" + repo + "/issues?state=all&page=1";

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "token " + token);
        HttpEntity<Void> request = new HttpEntity<>(headers);

        List<Issue> allIssues = new ArrayList<>();
        int currentPage = 1;

        while (uri != null && currentPage <= pages) {
            System.out.println("Fetching: " + uri);
            try {
                ResponseEntity<IssueData[]> response = restTemplate.exchange(
                        uri, HttpMethod.GET, request, IssueData[].class);

                if (response.getBody() != null) {
                    Arrays.stream(response.getBody()).forEach(issueData -> {
                        List<Comment> comments = commentService.getNotes(
                                owner, repo, issueData.number.toString());
                        Issue transformedIssue = transformer.transformIssue(issueData, comments);
                        allIssues.add(transformedIssue);
                    });
                }

                uri = getNextPageUrl(response.getHeaders());
                currentPage++;
            } catch (HttpClientErrorException.UnprocessableEntity e) {
                System.err.println("422 Unprocessable Entity: invalid pagination. Stopping here.");
                break;
            }
        }

        return allIssues;
    }

    public List<Issue> sinceIssues(String owner, String repo, Integer days, Integer pages) {
        String sinceDate = LocalDate.now().minusDays(days).toString();
        String uri = baseUri + owner + "/" + repo + "/issues?state=all&since=" + sinceDate + "&page=1";

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "token " + token);
        HttpEntity<Void> request = new HttpEntity<>(headers);

        List<Issue> allIssues = new ArrayList<>();
        int currentPage = 1;

        while (uri != null && currentPage <= pages) {
            System.out.println("Fetching: " + uri);
            try {
                ResponseEntity<IssueData[]> response = restTemplate.exchange(
                        uri, HttpMethod.GET, request, IssueData[].class);

                if (response.getBody() != null) {
                    Arrays.stream(response.getBody()).forEach(issueData -> {
                        List<Comment> comments = commentService.getNotes(
                                owner, repo, issueData.number.toString());
                        Issue transformedIssue = transformer.transformIssue(issueData, comments);
                        allIssues.add(transformedIssue);
                    });
                }

                uri = getNextPageUrl(response.getHeaders());
                currentPage++;
            } catch (HttpClientErrorException.UnprocessableEntity e) {
                System.err.println("422 Unprocessable Entity: invalid pagination. Stopping here.");
                break;
            }
        }

        return allIssues;
    }

    private String getNextPageUrl(HttpHeaders headers) {
        List<String> linkHeaders = headers.get("Link");
        if (linkHeaders == null || linkHeaders.isEmpty()) return null;

        for (String linkHeader : linkHeaders) {
            String[] parts = linkHeader.split(", ");
            for (String part : parts) {
                String[] section = part.split("; ");
                if (section.length == 2 && section[1].equals("rel=\"next\"")) {
                    String nextUrl = section[0].substring(1, section[0].length() - 1);
                    if (nextUrl.contains("after=")) return null;
                    return nextUrl;
                }
            }
        }

        return null;
    }
}
