package aiss.github;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GithubApplicationTests {

	@Test
	void contextLoads() {
	}

}
