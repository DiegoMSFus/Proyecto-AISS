package ProyectoAiss.BitBucket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BitBucketApplication {

	public static void main(String[] args) {
		SpringApplication.run(BitBucketApplication.class, args);
	}

}
